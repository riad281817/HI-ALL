from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import undetected_chromedriver as uc
import time
import random
import sys

LOGIN_URL = "https://www.facebook.com/login"
POST_URL = input("Enter Your Post URL: ").strip()

REACTION_ARIA_LABELS = {
    "like": "Like",
    "love": "Love",
    "haha": "Haha"
}

print("React options: like, love, haha")
selected_reaction = input("Choose your reaction type: ").strip().lower()

if selected_reaction not in REACTION_ARIA_LABELS:
    print("❌ Invalid reaction selected!")
    sys.exit()

reaction_label = REACTION_ARIA_LABELS[selected_reaction]

try:
    with open("accounts.txt", "r") as file:
        accounts = [line.strip().split(":") for line in file if ":" in line]
except FileNotFoundError:
    print("❌ accounts.txt ফাইল পাওয়া যায়নি!")
    sys.exit()

banned_accounts = []
HEADLESS = False  # True করলে ব্রাউজার দেখা যাবে না

for username, password in accounts:
    options = uc.ChromeOptions()

    prefs = {
        "profile.default_content_setting_values.notifications": 2,
        "profile.default_content_setting_values.geolocation": 2,
        "profile.default_content_setting_values.media_stream_mic": 2,
        "profile.default_content_setting_values.media_stream_camera": 2,
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False
    }

    options.add_experimental_option("prefs", prefs)
    options.add_argument("--disable-infobars")
    options.add_argument("--disable-save-password-bubble")
    options.add_argument("--incognito")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    if HEADLESS:
        options.add_argument("--headless=new")

    driver = uc.Chrome(options=options)
    wait = WebDriverWait(driver, 15)

    try:
        driver.get(LOGIN_URL)
        time.sleep(random.uniform(2, 4))

        wait.until(EC.presence_of_element_located((By.ID, "email"))).send_keys(username)
        driver.find_element(By.ID, "pass").send_keys(password)
        driver.find_element(By.NAME, "login").click()

        time.sleep(random.uniform(8, 15))

        try:
            not_now = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Not Now')]"))
            )
            not_now.click()
            print("↪️ Clicked 'Not Now'")
        except:
            pass

        current_url = driver.current_url
        if any(x in current_url for x in ["checkpoint", "recover", "login"]):
            print(f"{username} -> 🔒 Login failed বা checkpoint এসেছে")
            banned_accounts.append(f"{username}:{password}")
            driver.quit()
            continue

        driver.get(POST_URL)
        time.sleep(random.uniform(4, 6))

        try:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight / 3);")
            time.sleep(2)

            react_button = wait.until(EC.presence_of_element_located((
                By.XPATH,
                "//div[contains(@aria-label, 'Like') or contains(@aria-label, 'React') or contains(@aria-label, 'Send a reaction')]"
            )))

            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", react_button)
            time.sleep(2)

            actions = ActionChains(driver)
            actions.move_to_element(react_button).pause(2).perform()

            reaction_button = wait.until(EC.element_to_be_clickable((
                By.XPATH, f"//div[@aria-label='{reaction_label}']"
            )))
            driver.execute_script("arguments[0].click();", reaction_button)
            print(f"{username} -> ✅ Reacted with {selected_reaction}")

        except TimeoutException:
            print(f"{username} -> ❌ Could not find reaction button or '{reaction_label}'")

        time.sleep(random.uniform(1, 2))

    except Exception as e:
        print(f"{username} -> ❌ Error: {str(e)}")
        banned_accounts.append(f"{username}:{password}")

    finally:
        driver.quit()

if banned_accounts:
    with open("banned_accounts.txt", "w") as banned_file:
        for acc in banned_accounts:
            banned_file.write(acc + "\n")

print("✅ DONE, banned accounts are stored in banned_accounts.txt")